<div class="row">
    <div class="col-12">
        <table class="body-wrap"
            style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; width: 100%; background-color: transparent; margin: 0;">
            <tr style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                <td class="container" width="600"
                    style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; display: block !important; max-width: 600px !important; clear: both !important; margin: 0 auto;"
                    valign="top">
                    <div class="content"
                        style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; max-width: 600px; display: block; margin: 0 auto; padding: 20px;">
                        <table class="main" width="100%" cellpadding="0" cellspacing="0" itemprop="action" itemscope
                            itemtype="#http://schema.org/ConfirmAction"
                            style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; border-radius: 3px; margin: 0; border: none;">
                            <tr style="font-family: 'Roboto', sans-serif; font-size: 14px; margin: 0;">
                                <td class="content-wrap"
                                    style="font-family: 'Roboto', sans-serif; box-sizing: border-box; color: #495057; font-size: 14px; vertical-align: top; margin: 0;padding: 30px; box-shadow: 0 3px 15px rgba(30,32,37,.06); ;border-radius: 7px; background-color: #fff;"
                                    valign="top">
                                    <meta itemprop="name" content="Welcome Message"
                                        style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;" />
                                    <table width="100%" cellpadding="0" cellspacing="0"
                                        style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                        <tr
                                            style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                            <td class="content-block"
                                                style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
                                                valign="top">
                                                <div style="text-align: center;margin-bottom: 15px;">
                                                    <img src="<?php echo e(URL::asset('assets/logos/logo-text-blue.png')); ?>"
                                                        alt="" height="70px">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr
                                            style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                            <td class="content-block"
                                                style="font-family: 'Roboto', sans-serif; box-sizing: border-box; line-height: 1.5; font-size: 24px; vertical-align: top; margin: 0; padding: 0 0 10px;text-align: center; font-weight: 500;"
                                                valign="top">
                                                Booking Request Sent By <strong><?php echo $detail['email_id']; ?></strong>
                                            </td>
                                        </tr>
                                        <tr
                                            style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                            <td class="content-block"
                                                style="font-family: 'Roboto', sans-serif; color: #878a99; line-height: 1.5; box-sizing: border-box; font-size: 15px; vertical-align: top; margin: 0; padding: 0 0 24px; text-align: center;"
                                                valign="top">
                                                Name: <strong><?php echo e($detail['fullname']); ?></h1></strong>
                                            </td>
                                        </tr>
                                        <tr
                                            style="font-family: 'Roboto', sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
                                            <td class="content-block"
                                                style="font-family: 'Roboto', sans-serif; color: #878a99; line-height: 1.5; box-sizing: border-box; font-size: 15px; vertical-align: top; margin: 0; padding: 0 0 24px; text-align: center;"
                                                valign="top">
                                                message: <strong><?php echo $detail['message']; ?></strong>
                                            </td>
                                        </tr>

                                        
                                        <tr>
                                            <td></td>
                                        </tr>
                                        
                                        <tr>
                                            <td></td>
                                        </tr>
                                        
                                    </table>
                                </td>
                            </tr>
                        </table>
                        <div style="text-align: center; margin: 10px 0px auto;">
                            <p
                                style="font-family: 'Roboto', sans-serif; font-size: 14px;color: #98a6ad; margin:
                            0px;">
                                <?php echo e(date('Y')); ?> oneBhutanAdventures. Design & Develop by <a
                                    href="https://www.ibestbhutan.com">IBEST</a></p>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</div>
<?php /**PATH /Users/ibest/Desktop/tharchen/LawWeb/iBEST-Technologies/ui/resources/views/mails/bookNow.blade.php ENDPATH**/ ?>